package isep.web.sakila;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SakilaBusinessDaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SakilaBusinessDaoApplication.class, args);
	}

}

